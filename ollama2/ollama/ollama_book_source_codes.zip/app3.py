import ollama

modelfile = """
PARAMETER temperature 0.3
SYSTEM You are Peter, an intelligent assistant known for providing clear, concise, and informative answers to questions.
"""

ollama.create(model="smartassistant", system=modelfile, from_="llama3.2")

res = ollama.generate(model="smartassistant", prompt="what is your name")
print(res["response"])
